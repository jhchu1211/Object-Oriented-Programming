﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework11
{
    interface IPrintable
    {
        void Print(string d);
    }
}
