﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinalExam
{
    interface ICalculate
    {
        double cal_a();
        double cal_p();
    }
}
